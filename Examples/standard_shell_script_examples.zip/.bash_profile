# Sample .bash_profile for EXT tests.

if [ -f "$HOME/.bashrc" ]; then
  echo "Would load .bashrc here."
fi

export EXT_PROFILE_LOADED="true"
