#!/bin/sh
# Basic POSIX shell example for EXT.

APP_NAME="EXT"
GREETING="Hello from $APP_NAME"

say_hello() {
  name="$1"
  echo "$GREETING, $name"
}

for user in "editor" "preview" "workspace"; do
  say_hello "$user"
done

if [ -n "$APP_NAME" ]; then
  echo "App name is set."
fi
