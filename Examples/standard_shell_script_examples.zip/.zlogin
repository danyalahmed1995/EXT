# Sample .zlogin for EXT tests.

echo "Login shell example."
