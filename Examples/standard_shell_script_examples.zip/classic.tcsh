#!/usr/bin/env tcsh
# Tcsh example.

set app = "EXT"
set modes = (normal large huge)

foreach mode ($modes)
  echo "Mode: $mode"
end

if ("$app" == "EXT") then
  echo "Tcsh syntax fallback is okay."
endif
