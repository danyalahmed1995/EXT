# Sample .zprofile for EXT tests.

export EXT_ZPROFILE="loaded"
echo "Zprofile example."
