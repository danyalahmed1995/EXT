# Standard Shell Script Examples

Small shell-script files for testing EXT shell support.

What to verify:
- Supported extensions open as editable text.
- Known shell config filenames are recognized.
- Extensionless files with shell shebangs are recognized.
- Shell files do not open as Markdown preview documents.
- Save/edit preserves content exactly unless edited by the user.
