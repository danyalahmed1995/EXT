# Sample .bashrc for EXT tests.

export EXT_SAMPLE_MODE="shell-test"
alias ext_echo='echo EXT shell config loaded'

ext_prompt_info() {
  echo "Workspace: ${PWD}"
}
