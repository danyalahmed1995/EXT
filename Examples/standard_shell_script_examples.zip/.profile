# Sample .profile for EXT tests.

PATH="$HOME/bin:$PATH"
export PATH

echo "Profile parsed as editable shell text."
