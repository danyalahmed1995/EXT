# Sample .kshrc for EXT tests.

export EXT_KSHRC="loaded"
print "Ksh config example."
