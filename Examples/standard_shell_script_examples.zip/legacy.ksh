#!/usr/bin/env ksh
# KornShell example.

app="EXT"
typeset -i count=0

function tick {
  count=count+1
  print "[$count] $1"
}

for item in editor search outline; do
  tick "$app handles $item"
done
