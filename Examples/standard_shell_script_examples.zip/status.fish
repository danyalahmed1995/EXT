#!/usr/bin/env fish
# Fish shell example.

set app EXT
set features markdown mdx shell

function log_status
    set label $argv[1]
    echo "Feature enabled: $label"
end

for feature in $features
    log_status $feature
end

if test "$app" = "EXT"
    echo "Fish file opened safely."
end
