#!/usr/bin/env bash
# Bash-flavored script with arrays and functions.
set -u

project="EXT"
targets=("desktop" "preview" "benchmark")

log() {
  local level="$1"
  local message="$2"
  echo "[$level] $message"
}

for target in "${targets[@]}"; do
  log "info" "Preparing $project target: $target"
done

if [[ "$project" == "EXT" ]]; then
  log "ok" "Bash highlighting should work here."
fi
