# Sample .zlogout for EXT tests.

echo "Logout shell example."
