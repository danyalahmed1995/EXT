# Sample .zshenv for EXT tests.

export EXT_ZSHENV="available"
