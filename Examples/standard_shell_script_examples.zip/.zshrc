# Sample .zshrc for EXT tests.

export EXT_ZSH_THEME="minimal"
plugins=(git node)

autoload -Uz compinit
echo "Zsh config source text only."
