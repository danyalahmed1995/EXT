#!/usr/bin/env zsh
# Zsh example.

typeset -a plugins
plugins=(git editor preview)

function announce() {
  local item="$1"
  echo "Loading plugin: ${item}"
}

for plugin in $plugins; do
  announce "$plugin"
done

[[ -n "$ZSH_VERSION" ]] && echo "Running under zsh."
