#!/usr/bin/env csh
# C shell example.

set app = "EXT"
set features = (editor search navigation)

foreach feature ($features)
  echo "$app feature: $feature"
end

if ("$app" == "EXT") then
  echo "C shell file recognized."
endif
